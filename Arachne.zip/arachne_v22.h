#ifndef ARACHNE_V22_H
#define ARACHNE_V22_H

/* ═══════════════════════════════════════════════════════════
   ARACHNE v22  —  motor unificado
   ───────────────────────────────────────────────────────────
   Incorpora todas las mejoras del historial:

   De v17.1:
     · resonancia con corto-circuito -999 (polaridad igual)
     · connect_centers O(n) con Fisher-Yates + sample de 8
     · BFS top-4 vecinos por resonancia hacia target
     · promote_centers redirige vecinos al nuevo centro
     · weave_pulse threshold >= 2.0
     · decay de usage (factor 0.8)
     · disconnect limpia y simétrica
     · is_core_ring protege el anillo base
     · EventLog circular (500 eventos)

   De v18:
     · Cell = 1 centro + 6 nodos
     · Pegado de celdas por frontera ordenada por resonancia
     · fill_gaps anti-huecos automático
     · ac_cell_score = suma de resonancias inter-celda

   De v18.1:
     · Ring = anillo de celdas con cierre de ciclo
     · Elevación automática al cerrar ciclo
     · Desfase angular acumulado (espiral 3D)
     · Coordenadas 3D: radio = 1 + layer*2, ángulo con desfase
     · Export JSON (compatible con visualizador)

   De v22 (Python):
     · Coords 3D compactas en la celda
     · Export JSON limpio por celdas + vecinas
     · run(steps) en una llamada
   ═══════════════════════════════════════════════════════════ */

#include <stddef.h>

/* ── Constantes ───────────────────────────────────────── */

#define AV22_MAX_NODES       524288   /* 512 K nodos                 */
#define AV22_MAX_CELLS       8192    /* 64 K celdas                 */
#define AV22_MAX_RINGS       256
#define AV22_MAX_CONN        6        /* conexiones por nodo         */
#define AV22_CELL_SIZE       7        /* 1 centro + 6 vecinos        */
#define AV22_CELL_MAX_NBRS   32       /* celdas vecinas por celda    */
#define AV22_RING_MAX_CELLS  64       /* celdas por anillo           */
#define AV22_RING_MIN_CLOSE  6        /* celdas para cerrar ciclo    */
#define AV22_ATTACH_LINKS    3        /* aristas al pegar 2 celdas   */
#define AV22_HUB_THRESHOLD   6.0f
#define AV22_DECAY_FACTOR    0.8f
#define AV22_SAMPLE_SIZE     8        /* para connect_centers O(n)   */
#define AV22_EVENTLOG_SIZE   500
#define AV22_CORE_RING_SIZE  6

/* ── Nodo ─────────────────────────────────────────────── */

typedef struct {
    int   id;
    int   polarity;
    int   connections[AV22_MAX_CONN];
    int   conn_count;
    int   center;           /* id del nodo centro de su celda, -1 si libre */
    int   layer;
    float usage;
    float gravity;
    int   is_core_ring;
} AV22Node;

/* ── Celda ────────────────────────────────────────────── */

typedef struct {
    int   id;
    int   center_node;
    int   nodes[AV22_CELL_SIZE];
    int   node_count;
    int   neighbors[AV22_CELL_MAX_NBRS];
    int   neighbor_count;
    int   layer;
    float angle;            /* ángulo en el anillo (desfase acumulado)     */
    float x, y, z;          /* coordenadas 3D calculadas                   */
    int   active;
} AV22Cell;

/* ── Anillo ───────────────────────────────────────────── */

typedef struct {
    int   id;
    int   cells[AV22_RING_MAX_CELLS];
    int   cell_count;
    int   layer;
    float angle_offset;     /* desfase acumulado en grados                 */
    int   closed;
} AV22Ring;

/* ── EventLog ─────────────────────────────────────────── */

typedef struct {
    char  type[48];
    int   a, b;
    float val;
} AV22Event;

typedef struct {
    AV22Event entries[AV22_EVENTLOG_SIZE];
    int head;
    int count;
} AV22EventLog;

/* ── Motor principal ──────────────────────────────────── */

typedef struct {
    /* Nodos */
    AV22Node    *nodes;         /* malloc AV22_MAX_NODES               */
    int          node_count;

    /* Celdas */
    AV22Cell    *cells;         /* malloc AV22_MAX_CELLS               */
    int          cell_count;

    /* Anillos */
    AV22Ring     rings[AV22_MAX_RINGS];
    int          ring_count;
    int          current_ring;  /* índice del anillo activo            */

    /* Centros (nodos hub) */
    int          centers[AV22_MAX_CELLS];
    int          center_count;

    /* Log */
    AV22EventLog log;
} AV22;

/* ═══════════════════════════════════════════════════════════
   API pública
   ═══════════════════════════════════════════════════════════ */

/* Ciclo de vida */
int   av22_init        (AV22 *a);
void  av22_free        (AV22 *a);

/* Nodos */
int   av22_add_node    (AV22 *a, int polarity);
int   av22_connect     (AV22 *a, int na, int nb);
int   av22_disconnect  (AV22 *a, int na, int nb);
float av22_resonance   (AV22 *a, int na, int nb);  /* -999 si XOR inválido */
void  av22_gravity     (AV22 *a, int id);
void  av22_decay       (AV22 *a);

/* Celdas */
int   av22_create_cell (AV22 *a, int center);      /* genera 6 vecinos auto */
int   av22_attach      (AV22 *a, int ca, int cb);  /* pega por frontera     */
void  av22_fill_gaps   (AV22 *a, int cell_id);
float av22_cell_score  (AV22 *a, int ca, int cb);

/* Anillos + elevación */
int   av22_grow        (AV22 *a);          /* crea celda → añade al anillo  */
int   av22_check_cycle (AV22 *a);          /* retorna 1 si cerró el anillo  */
void  av22_elevate     (AV22 *a);          /* archiva anillo → nuevo nivel  */
void  av22_step        (AV22 *a);          /* grow + check + elevate        */
void  av22_run         (AV22 *a, int n);   /* n pasos completos             */

/* Mantenimiento del grafo */
void  av22_connect_centers (AV22 *a);      /* O(n) con sample Fisher-Yates  */
void  av22_promote_centers (AV22 *a);
void  av22_weave_pulse     (AV22 *a);      /* threshold >= 2.0              */

/* Búsqueda BFS top-4 */
int   av22_search      (AV22 *a, int start, int target,
                        int *path_out, int path_cap);

/* Coordenadas 3D */
void  av22_compute_coords (AV22 *a);

/* Export */
int   av22_export_json (AV22 *a, const char *path);

/* Debug */
void  av22_log_record  (AV22 *a, const char *type, int x, int y, float v);
void  av22_log_print   (AV22 *a, int last_n);
void  av22_print_stats (AV22 *a);

#endif /* ARACHNE_V22_H */
