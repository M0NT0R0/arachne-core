#include <stdio.h>
#include <stdlib.h>
#include "arachne_v22.h"

int main(void)
{
    AV22 *a = malloc(sizeof(AV22));
    if (!a) { printf("ERROR: malloc fallido\n"); return 1; }

    if (!av22_init(a)) {
        printf("ERROR: init fallido\n");
        free(a); return 1;
    }

    av22_run(a, 80);

    av22_connect_centers(a);
    av22_promote_centers(a);
    av22_weave_pulse(a);
    av22_decay(a);

    if (a->node_count >= 2) {
        int path[256];
        int len = av22_search(a, 0, a->node_count - 1, path, 256);
        if (len > 0)
            printf("Ruta 0 -> %d: %d saltos\n", a->node_count - 1, len - 1);
        else
            printf("Sin ruta directa\n");
    }

    av22_print_stats(a);
    av22_log_print(a, 8);
    av22_export_json(a, "arachne_v22.json");
    printf("JSON exportado: arachne_v22.json\n");

    av22_free(a);
    free(a);
    return 0;
}
