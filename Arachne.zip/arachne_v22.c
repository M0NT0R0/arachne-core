#include "arachne_v22.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

/* ═══════════════════════════════════════════════════════════
   ARACHNE v22
   ═══════════════════════════════════════════════════════════ */

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/* ──────────────────────────────────────────────────────────
   HELPERS INTERNOS
   ────────────────────────────────────────────────────────── */

static int _conn_has(AV22Node *n, int id)
{
    for (int i = 0; i < n->conn_count; i++)
        if (n->connections[i] == id) return 1;
    return 0;
}

static void _conn_remove(AV22Node *n, int id)
{
    for (int i = 0; i < n->conn_count; i++) {
        if (n->connections[i] == id) {
            n->connections[i] = n->connections[--n->conn_count];
            return;
        }
    }
}

static int _is_center(AV22 *a, int id)
{
    for (int i = 0; i < a->center_count; i++)
        if (a->centers[i] == id) return 1;
    return 0;
}

static void _add_center(AV22 *a, int id)
{
    if (a->center_count >= AV22_MAX_CELLS) return;
    if (_is_center(a, id)) return;
    a->centers[a->center_count++] = id;
}

static int _cell_has_nbr(AV22Cell *c, int id)
{
    for (int i = 0; i < c->neighbor_count; i++)
        if (c->neighbors[i] == id) return 1;
    return 0;
}

static void _cell_add_nbr(AV22Cell *a, AV22Cell *b)
{
    if (!_cell_has_nbr(a, b->id) && a->neighbor_count < AV22_CELL_MAX_NBRS)
        a->neighbors[a->neighbor_count++] = b->id;
    if (!_cell_has_nbr(b, a->id) && b->neighbor_count < AV22_CELL_MAX_NBRS)
        b->neighbors[b->neighbor_count++] = a->id;
}

static AV22Ring *_cur_ring(AV22 *a)
{
    return &a->rings[a->current_ring];
}

/* ──────────────────────────────────────────────────────────
   EVENTLOG
   ────────────────────────────────────────────────────────── */

void av22_log_record(AV22 *a, const char *type, int x, int y, float v)
{
    AV22Event *ev = &a->log.entries[a->log.head];
    strncpy(ev->type, type, 47); ev->type[47] = '\0';
    ev->a = x; ev->b = y; ev->val = v;
    a->log.head = (a->log.head + 1) % AV22_EVENTLOG_SIZE;
    if (a->log.count < AV22_EVENTLOG_SIZE) a->log.count++;
}

void av22_log_print(AV22 *a, int last_n)
{
    int show  = last_n < a->log.count ? last_n : a->log.count;
    int start = (a->log.head - show + AV22_EVENTLOG_SIZE) % AV22_EVENTLOG_SIZE;
    printf("── AV22 EventLog (last %d) ──\n", show);
    for (int i = 0; i < show; i++) {
        AV22Event *ev = &a->log.entries[(start + i) % AV22_EVENTLOG_SIZE];
        printf("  [%s] a=%d b=%d val=%.2f\n", ev->type, ev->a, ev->b, ev->val);
    }
}

/* ──────────────────────────────────────────────────────────
   CICLO DE VIDA
   ────────────────────────────────────────────────────────── */

int av22_init(AV22 *a)
{
    memset(a, 0, sizeof(AV22));

    a->nodes = calloc(AV22_MAX_NODES, sizeof(AV22Node));
    a->cells = calloc(AV22_MAX_CELLS, sizeof(AV22Cell));

    if (!a->nodes || !a->cells) {
        free(a->nodes); free(a->cells);
        return 0;
    }

    /* center = -1 por defecto */
    for (int i = 0; i < AV22_MAX_NODES; i++) a->nodes[i].center = -1;

    /* primer anillo vacío */
    a->ring_count   = 1;
    a->current_ring = 0;
    a->rings[0].id  = 0;

    return 1;
}

void av22_free(AV22 *a)
{
    free(a->nodes);
    free(a->cells);
    a->nodes = NULL;
    a->cells = NULL;
}

/* ──────────────────────────────────────────────────────────
   NODOS
   ────────────────────────────────────────────────────────── */

int av22_add_node(AV22 *a, int polarity)
{
    if (a->node_count >= AV22_MAX_NODES) return -1;
    int id = a->node_count++;
    AV22Node *n = &a->nodes[id];
    n->id       = id;
    n->polarity = polarity & 1;
    n->center   = -1;
    av22_log_record(a, "node_add", id, -1, (float)polarity);
    return id;
}

int av22_connect(AV22 *a, int ai, int bi)
{
    if (ai == bi || ai < 0 || bi < 0)         return 0;
    if (ai >= a->node_count || bi >= a->node_count) return 0;
    AV22Node *na = &a->nodes[ai], *nb = &a->nodes[bi];
    if (_conn_has(na, bi))                     return 0;
    if (na->conn_count >= AV22_MAX_CONN)       return 0;
    if (nb->conn_count >= AV22_MAX_CONN)       return 0;
    if (!(na->polarity ^ nb->polarity))        return 0;
    na->connections[na->conn_count++] = bi;
    nb->connections[nb->conn_count++] = ai;
    av22_gravity(a, ai); av22_gravity(a, bi);
    return 1;
}

int av22_disconnect(AV22 *a, int ai, int bi)
{
    if (ai < 0 || bi < 0) return 0;
    if (ai >= a->node_count || bi >= a->node_count) return 0;
    AV22Node *na = &a->nodes[ai], *nb = &a->nodes[bi];
    int removed = 0;
    if (_conn_has(na, bi)) { _conn_remove(na, bi); removed = 1; }
    if (_conn_has(nb, ai)) { _conn_remove(nb, ai); removed = 1; }
    if (removed) { av22_gravity(a, ai); av22_gravity(a, bi); }
    return removed;
}

/* [v17.1 FIX-2] corto-circuito -999 si polaridades iguales */
float av22_resonance(AV22 *a, int ai, int bi)
{
    if (ai < 0 || bi < 0) return -999.0f;
    if (ai >= a->node_count || bi >= a->node_count) return -999.0f;
    AV22Node *na = &a->nodes[ai], *nb = &a->nodes[bi];

    if (!(na->polarity ^ nb->polarity)) return -999.0f;

    float score = 0.0f;
    if (na->center == nb->center && na->center != -1) score += 1.0f;
    if (abs(na->layer - nb->layer) <= 1)              score += 1.0f;

    /* vecinos compartidos */
    for (int i = 0; i < na->conn_count; i++)
        for (int j = 0; j < nb->conn_count; j++)
            if (na->connections[i] == nb->connections[j])
                score += 0.5f;

    return score;
}

void av22_gravity(AV22 *a, int id)
{
    if (id < 0 || id >= a->node_count) return;
    AV22Node *n = &a->nodes[id];
    n->gravity = (float)n->conn_count + n->usage;
}

/* [v17.1 NEW-3] decay de usage */
void av22_decay(AV22 *a)
{
    for (int i = 0; i < a->node_count; i++) {
        a->nodes[i].usage *= AV22_DECAY_FACTOR;
        av22_gravity(a, i);
    }
    av22_log_record(a, "decay", -1, -1, AV22_DECAY_FACTOR);
}

/* ──────────────────────────────────────────────────────────
   CELDAS
   ────────────────────────────────────────────────────────── */

/* Crea celda generando 6 nodos vecinos automáticamente.
   El centro debe existir ya en el grafo. */
int av22_create_cell(AV22 *a, int center)
{
    if (center < 0 || center >= a->node_count) return -1;
    if (a->cell_count >= AV22_MAX_CELLS)        return -1;

    int id      = a->cell_count++;
    AV22Cell *c = &a->cells[id];
    c->id            = id;
    c->center_node   = center;
    c->node_count    = 0;
    c->neighbor_count = 0;
    c->layer         = 0;
    c->angle         = 0.0f;
    c->active        = 1;

    c->nodes[c->node_count++] = center;
    a->nodes[center].center   = center;

    /* generar 6 vecinos con polaridad siempre opuesta al centro
       para garantizar que av22_connect pase el XOR */
    int nbr_pol = a->nodes[center].polarity ^ 1;
    int added   = 0;

    while (added < AV22_CELL_SIZE - 1) {
        int nid = av22_add_node(a, nbr_pol);
        if (nid < 0) break;
        a->nodes[nid].center = center;
        a->nodes[nid].layer  = a->nodes[center].layer;
        if (av22_connect(a, center, nid)) {
            c->nodes[c->node_count++] = nid;
            added++;
        }
    }

    /* [v18 fix] validar que la celda quedó completa */
    if (c->node_count < AV22_CELL_SIZE) {
        c->active = 0;
        a->cell_count--;
        return -1;
    }

    av22_log_record(a, "cell_create", id, center, (float)c->node_count);
    return id;
}

/* Score de afinidad entre dos celdas */
float av22_cell_score(AV22 *a, int ca_id, int cb_id)
{
    if (ca_id < 0 || ca_id >= a->cell_count) return 0.0f;
    if (cb_id < 0 || cb_id >= a->cell_count) return 0.0f;
    AV22Cell *ca = &a->cells[ca_id], *cb = &a->cells[cb_id];
    float score = 0.0f;
    for (int i = 0; i < ca->node_count; i++)
        for (int j = 0; j < cb->node_count; j++) {
            float r = av22_resonance(a, ca->nodes[i], cb->nodes[j]);
            if (r > 0) score += r;
        }
    return score;
}

/* [v18] Pegar dos celdas por frontera — top-3 pares por resonancia */
int av22_attach(AV22 *a, int ca_id, int cb_id)
{
    if (ca_id == cb_id)                        return 0;
    if (ca_id < 0 || ca_id >= a->cell_count)   return 0;
    if (cb_id < 0 || cb_id >= a->cell_count)   return 0;
    AV22Cell *ca = &a->cells[ca_id], *cb = &a->cells[cb_id];
    if (!ca->active || !cb->active)            return 0;
    if (_cell_has_nbr(ca, cb_id))              return 0;
    if (ca->neighbor_count >= AV22_CELL_MAX_NBRS) return 0;
    if (cb->neighbor_count >= AV22_CELL_MAX_NBRS) return 0;

    /* recopilar pares válidos ordenados por resonancia */
    typedef struct { int ai; int bi; float r; } Pair;
    Pair pairs[AV22_CELL_SIZE * AV22_CELL_SIZE];
    int  np = 0;

    for (int i = 0; i < ca->node_count; i++)
        for (int j = 0; j < cb->node_count; j++) {
            float r = av22_resonance(a, ca->nodes[i], cb->nodes[j]);
            if (r > -999.0f) {
                pairs[np].ai = ca->nodes[i];
                pairs[np].bi = cb->nodes[j];
                pairs[np].r  = r;
                np++;
            }
        }

    /* burbuja sobre np ≤ 49 */
    for (int x = 0; x < np - 1; x++)
        for (int y = x + 1; y < np; y++)
            if (pairs[y].r > pairs[x].r) {
                Pair t = pairs[x]; pairs[x] = pairs[y]; pairs[y] = t;
            }

    int links = 0;
    for (int k = 0; k < np && links < AV22_ATTACH_LINKS; k++)
        if (av22_connect(a, pairs[k].ai, pairs[k].bi)) links++;

    if (links == 0) return 0;
    _cell_add_nbr(ca, cb);
    av22_log_record(a, "cells_attach", ca_id, cb_id, (float)links);
    return 1;
}

/* [v18] Anti-huecos */
void av22_fill_gaps(AV22 *a, int cell_id)
{
    if (cell_id < 0 || cell_id >= a->cell_count) return;
    AV22Cell *c = &a->cells[cell_id];
    if (!c->active) return;
    if (c->neighbor_count >= 3) return;

    for (int i = 0; i < a->cell_count && c->neighbor_count < 3; i++) {
        if (i == cell_id || !a->cells[i].active) continue;
        if (_cell_has_nbr(c, i)) continue;
        av22_attach(a, cell_id, i);
    }
}

/* ──────────────────────────────────────────────────────────
   ANILLOS + ELEVACIÓN
   ────────────────────────────────────────────────────────── */

/* Crea una celda nueva y la añade al anillo activo */
int av22_grow(AV22 *a)
{
    AV22Ring *r = _cur_ring(a);
    if (r->closed) return -1;

    /* crear nodo centro */
    int pol    = a->node_count % 2;
    int center = av22_add_node(a, pol);
    if (center < 0) return -1;

    a->nodes[center].layer = r->layer;

    int cid = av22_create_cell(a, center);
    if (cid < 0) return -1;

    a->cells[cid].layer = r->layer;

    /* añadir al anillo */
    if (r->cell_count >= AV22_RING_MAX_CELLS) return -1;
    r->cells[r->cell_count++] = cid;

    /* pegar con la celda anterior del anillo */
    if (r->cell_count > 1) {
        int prev = r->cells[r->cell_count - 2];
        av22_attach(a, cid, prev);
    }

    return cid;
}

/* [v18.1] Cierra el ciclo cuando el anillo alcanza el mínimo */
int av22_check_cycle(AV22 *a)
{
    AV22Ring *r = _cur_ring(a);
    if (r->closed)                          return 0;
    if (r->cell_count < AV22_RING_MIN_CLOSE) return 0;

    /* [v18.1 fix] cerrar arista primera ↔ última antes de elevar */
    int first = r->cells[0];
    int last  = r->cells[r->cell_count - 1];
    av22_attach(a, last, first);

    r->closed = 1;
    av22_log_record(a, "ring_closed", r->id, r->cell_count, (float)r->layer);
    return 1;
}

/* [v18.1] Elevar nivel — archivar anillo + crear el siguiente con desfase */
void av22_elevate(AV22 *a)
{
    if (a->ring_count >= AV22_MAX_RINGS) return;

    AV22Ring *old = _cur_ring(a);
    if (!old->closed) return;

    int new_idx = a->ring_count++;
    AV22Ring *nr = &a->rings[new_idx];

    nr->id           = new_idx;
    nr->layer        = old->layer + 1;
    nr->angle_offset = old->angle_offset + 60.0f;  /* desfase angular 60° */
    nr->cell_count   = 0;
    nr->closed       = 0;

    a->current_ring  = new_idx;

    av22_log_record(a, "ring_elevate", new_idx, old->id, (float)nr->layer);

    /* sembrar primera celda del nuevo nivel */
    av22_grow(a);
}

/* Paso completo: grow + check_cycle + elevate si procede */
void av22_step(AV22 *a)
{
    int cid = av22_grow(a);
    if (cid < 0) return;
    if (av22_check_cycle(a))
        av22_elevate(a);
}

void av22_run(AV22 *a, int n)
{
    for (int i = 0; i < n; i++)
        av22_step(a);
}

/* ──────────────────────────────────────────────────────────
   MANTENIMIENTO DEL GRAFO
   ────────────────────────────────────────────────────────── */

/* [v17.1 FIX-1] connect_centers O(n) con Fisher-Yates */
void av22_connect_centers(AV22 *a)
{
    if (a->center_count < 2) return;

    int pool[AV22_MAX_CELLS];
    for (int i = 0; i < a->center_count; i++) {
        int ci = a->centers[i];

        /* construir pool sin ci */
        int pool_n = 0;
        for (int j = 0; j < a->center_count; j++)
            if (j != i) pool[pool_n++] = a->centers[j];

        /* Fisher-Yates parcial */
        int sn = pool_n < AV22_SAMPLE_SIZE ? pool_n : AV22_SAMPLE_SIZE;
        for (int k = 0; k < sn; k++) {
            int r   = k + rand() % (pool_n - k);
            int tmp = pool[k]; pool[k] = pool[r]; pool[r] = tmp;
        }

        /* burbuja sobre sn ≤ 8 por resonancia descendente */
        for (int x = 0; x < sn - 1; x++)
            for (int y = x + 1; y < sn; y++)
                if (av22_resonance(a, ci, pool[x]) <
                    av22_resonance(a, ci, pool[y])) {
                    int t = pool[x]; pool[x] = pool[y]; pool[y] = t;
                }

        int links = 0;
        for (int k = 0; k < sn && links < 4; k++)
            if (av22_connect(a, ci, pool[k])) links++;
    }
}

/* [v17.1 FIX-4] promote_centers — redirige vecinos al nuevo centro */
void av22_promote_centers(AV22 *a)
{
    for (int i = 0; i < a->node_count; i++) {
        AV22Node *n = &a->nodes[i];
        if (n->gravity <= AV22_HUB_THRESHOLD) continue;
        if (_is_center(a, i))                  continue;
        _add_center(a, i);
        n->center = i;
        n->layer  = 0;
        for (int k = 0; k < n->conn_count; k++)
            a->nodes[n->connections[k]].center = i;
        av22_log_record(a, "center_promote", i, -1, n->gravity);
    }
}

/* [v17.1 FIX-5] weave_pulse con threshold >= 2.0 */
void av22_weave_pulse(AV22 *a)
{
    int pruned = 0;
    for (int i = 0; i < a->node_count; i++) {
        AV22Node *n = &a->nodes[i];
        if (n->is_core_ring)    continue;
        if (_is_center(a, i))   continue;
        if (n->conn_count <= 1) continue;
        if (n->gravity >= 2.0f) continue;

        int   worst = -1;
        float wr    = 1e9f;
        for (int k = 0; k < n->conn_count; k++) {
            float r = av22_resonance(a, i, n->connections[k]);
            if (r < wr) { wr = r; worst = n->connections[k]; }
        }
        if (worst >= 0) { av22_disconnect(a, i, worst); pruned++; }
    }
    av22_log_record(a, "weave_pulse", -1, -1, (float)pruned);
}

/* ──────────────────────────────────────────────────────────
   BÚSQUEDA BFS top-4
   ────────────────────────────────────────────────────────── */

int av22_search(AV22 *a, int start, int target, int *path_out, int cap)
{
    if (start < 0 || start >= a->node_count) return -1;
    if (target < 0 || target >= a->node_count) return -1;

    int *visited = calloc(a->node_count, sizeof(int));
    int *parent  = malloc(a->node_count * sizeof(int));
    int *queue   = malloc(a->node_count * sizeof(int));
    if (!visited || !parent || !queue) {
        free(visited); free(parent); free(queue); return -1;
    }
    for (int i = 0; i < a->node_count; i++) parent[i] = -1;

    int front = 0, back = 0, found = 0;
    queue[back++] = start;
    visited[start] = 1;

    while (front < back && !found) {
        int cur = queue[front++];
        if (cur == target) { found = 1; break; }

        AV22Node *n  = &a->nodes[cur];
        int  nbuf[AV22_MAX_CONN];
        float rr[AV22_MAX_CONN];
        int  nsz = 0;

        for (int k = 0; k < n->conn_count; k++) {
            int nb = n->connections[k];
            if (!visited[nb]) {
                nbuf[nsz] = nb;
                rr[nsz]   = av22_resonance(a, nb, target);
                nsz++;
            }
        }

        /* burbuja descendente sobre nsz ≤ 6 */
        for (int x = 0; x < nsz - 1; x++)
            for (int y = x + 1; y < nsz; y++)
                if (rr[y] > rr[x]) {
                    int ti = nbuf[x]; nbuf[x] = nbuf[y]; nbuf[y] = ti;
                    float tf = rr[x]; rr[x] = rr[y]; rr[y] = tf;
                }

        int lim = nsz < 4 ? nsz : 4;
        for (int k = 0; k < lim; k++) {
            int nb = nbuf[k];
            if (!visited[nb]) {
                visited[nb] = 1;
                parent[nb]  = cur;
                queue[back++] = nb;
            }
        }
    }

    int len = -1;
    if (found) {
        int tmp[AV22_MAX_NODES];
        int tl = 0, cur = target;
        while (cur != -1) {
            tmp[tl++] = cur;
            cur = (cur == start) ? -1 : parent[cur];
        }
        len = tl < cap ? tl : cap;
        for (int i = 0; i < len; i++) path_out[i] = tmp[tl - 1 - i];
        a->nodes[target].usage += 1.0f;
        av22_gravity(a, target);
    }

    free(visited); free(parent); free(queue);
    return len;
}

/* ──────────────────────────────────────────────────────────
   COORDENADAS 3D
   ────────────────────────────────────────────────────────── */

/* [v22] radio = 1 + layer*2, ángulo con desfase acumulado por nivel */
void av22_compute_coords(AV22 *a)
{
    for (int ri = 0; ri < a->ring_count; ri++) {
        AV22Ring *r  = &a->rings[ri];
        float radius = 1.0f + r->layer * 2.0f;
        float height = r->layer * 1.5f;
        float aoff   = r->angle_offset * (float)(M_PI / 180.0);
        int   n      = r->cell_count;

        for (int ci = 0; ci < n; ci++) {
            int cid = r->cells[ci];
            if (cid < 0 || cid >= a->cell_count) continue;
            AV22Cell *c = &a->cells[cid];

            float angle = aoff + (n > 0 ? (float)ci / n * 2.0f * (float)M_PI : 0.0f);
            c->angle = angle;
            c->x     = radius * cosf(angle);
            c->y     = height;
            c->z     = radius * sinf(angle);
        }
    }
}

/* ──────────────────────────────────────────────────────────
   EXPORT JSON
   ────────────────────────────────────────────────────────── */

int av22_export_json(AV22 *a, const char *path)
{
    av22_compute_coords(a);

    FILE *f = fopen(path, "w");
    if (!f) return 0;

    fprintf(f, "{\n  \"nodes\": [\n");
    int fn = 1;
    for (int ri = 0; ri < a->ring_count; ri++) {
        AV22Ring *r = &a->rings[ri];
        for (int ci = 0; ci < r->cell_count; ci++) {
            int cid = r->cells[ci];
            if (cid < 0 || cid >= a->cell_count) continue;
            AV22Cell *c = &a->cells[cid];
            if (!fn) fprintf(f, ",\n");
            fn = 0;
            fprintf(f,
                "    {\"id\":%d,\"ring\":%d,\"layer\":%d,"
                "\"x\":%.4f,\"y\":%.4f,\"z\":%.4f}",
                cid, ri, r->layer, c->x, c->y, c->z);
        }
    }
    fprintf(f, "\n  ],\n  \"edges\": [\n");

    int fe = 1;
    for (int ci = 0; ci < a->cell_count; ci++) {
        AV22Cell *c = &a->cells[ci];
        if (!c->active) continue;
        for (int k = 0; k < c->neighbor_count; k++) {
            int nb = c->neighbors[k];
            if (nb > ci) {
                if (!fe) fprintf(f, ",\n");
                fe = 0;
                fprintf(f, "    {\"a\":%d,\"b\":%d}", ci, nb);
            }
        }
    }
    fprintf(f, "\n  ],\n");
    fprintf(f,
        "  \"meta\":{\"rings\":%d,\"cells\":%d,\"nodes\":%d}\n}\n",
        a->ring_count, a->cell_count, a->node_count);

    fclose(f);
    return 1;
}

/* ──────────────────────────────────────────────────────────
   DEBUG
   ────────────────────────────────────────────────────────── */

void av22_print_stats(AV22 *a)
{
    int total_conn = 0;
    for (int i = 0; i < a->node_count; i++)
        total_conn += a->nodes[i].conn_count;

    printf("── ARACHNE v22 STATS ──\n");
    printf("  nodos          : %d\n",   a->node_count);
    printf("  celdas activas : %d\n",   a->cell_count);
    printf("  anillos        : %d\n",   a->ring_count);
    printf("  nivel actual   : %d\n",   _cur_ring(a)->layer);
    printf("  conexiones     : %d\n",   total_conn / 2);
    printf("  avg_degree     : %.2f\n",
           a->node_count ? (float)total_conn / a->node_count : 0.0f);
    printf("  centros        : %d\n",   a->center_count);
    printf("  log_eventos    : %d\n",   a->log.count);
}
